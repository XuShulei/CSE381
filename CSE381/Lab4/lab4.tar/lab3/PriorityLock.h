#include "thread.h"
#include "lock.h"
#include "CV.h"

class PriorityLock {
  int priority;

}
